<a id=edit_contact href="contact_page.php?edit_contact_upate=<?php if(isset($_GET['edit_contact']))
			echo $_GET['edit_contact'];
		?>" name="edit_contact" ><li class="action edit">Edit</li></a>