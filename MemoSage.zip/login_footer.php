
		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="simplenav">
								<a href="index.php">Home</a> | 
								<a href="about.php">About</a> |
								<a href="contact.php">Contact</a> |
								<a href="logout.php">LogOut</a> 
							</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Copyright &copy; 2016,Designed by <a href="#" rel="designer">Abhishek</a> 
							</p>
						</div>
					</div>

				</div> 
			</div>
		</div>

	</footer>	